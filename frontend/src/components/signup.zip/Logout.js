// import axios from "axios";

// function Logout() {
//     <form onSubmit={(e) => {
//         e.preventDefault();
//         axios({
//             url: 'http://localhost:8080/logout',
//             method: 'post',
//         }).then((res) => {
//             alert(res.data.msg);
//             localStorage.clear();
//             console.log(localStorage.getItem("userId"));
//             // window.location = '/';
//         });
//     }}>
//     </form>
// }

// export default Logout;
//필요없어짐