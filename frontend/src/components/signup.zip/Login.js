import axios from "axios";
import { useEffect } from "react";

function Login() {

    useEffect(() => {
        if (localStorage.getItem("id") != null) {
            alert('로그인 되어있습니다.');
            window.location = '/';
        }
    })

    return (
        <form onSubmit={(e) => {
            e.preventDefault();
            const formData = new FormData();
            const userId = e.target['0'].value;
            const userPw = e.target['1'].value;
            formData.append("userId", userId);
            formData.append('userPw', userPw);
            axios({
                url: 'http://localhost:8080/login',
                method: 'post',
                data: formData
            }).then((res) => {
                console.log(res.data)
                if (res.data != null) {
                    localStorage.setItem("id", res.data.user.id);
                    localStorage.setItem("userId", res.data.user.userId);
                    localStorage.setItem("userPw", res.data.user.userPw);
                    localStorage.setItem("userEmail", res.data.user.userEmail);
                    localStorage.setItem("userCash", res.data.user.userCash);
                    console.log(localStorage.getItem("id"));
                    console.log(localStorage.getItem("userId"));
                    console.log(localStorage.getItem("userPw"));
                    console.log(localStorage.getItem("userEmail"));
                    console.log(localStorage.getItem("userCash"));
                    window.location = '/';
                }
                alert(res.data.msg);
            });
        }}>
            ID : <input type="text" name="userId" /><br />
            PW : <input type="password" name="userPw" /><br />
            <input type="submit" value="로그인" />
        </form>
    )
    
}

export default Login;