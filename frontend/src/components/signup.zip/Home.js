import axios from "axios";

function Home() {
    return (
        <div>
            <form>
                <h1>{localStorage.getItem("userId")}님 반갑습니다.</h1>
                {/* <a text="'현재 캐쉬 : ' + ${localStorage.getItem(userCash)}"></a><br /> */}
                {/* <button type="button" onclick="location.href='http://localhost:8080/userinfo'">개인 정보 조회</button> */}
                <input type="button" value="로그아웃" onClick={(e) => {
                    e.preventDefault();
                    axios({
                        url: 'http://localhost:8080/logout',
                        method: 'post'
                    }).then((res) => {
                        console.log(res.data);
                        if (res.data.code === 100) {
                            console.log(res.data);
                            localStorage.clear();
                            console.log(localStorage.getItem("userId"));
                        }
                    });
                }} />
            </form>
        </div>
    )

    //         <div th:unless="${session.user} != null">
    //             로그인되어 있지 않습니다.<br/>
    //                 <button type="button" onclick="location.href='http://localhost:8080/login'">로그인</button>
    //                 <button type="button" onclick="location.href='http://localhost:8080/signup'">회원가입</button>
    //         </div>


    // const logout = () => {
    //             axios({
    //                 url: '/logout',
    //                 method: 'post',
    //             }).then((res) => {
    //                 alert('로그아웃 되었습니다.');
    //                 location.href = 'http://localhost:8080/home'
    //             });
    // }

}

export default Home;